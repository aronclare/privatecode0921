bootstrap 前端框架
bootstrap4-duallistbox 双向select选择框控件
bootstrap-colorpicker 颜色提取
bootstrap-switch 开关
codemirror 在线代码编辑
daterangepicker 选择日期范围，日期和时间
fastclick 移动端点击延迟
fontawesome-free 字体库
icheck-bootstrap 复选框/单选框美化
jquery
jquery-form 表单异步提交
jquery-tags-input 标签插件
moment 不可删除
overlayScrollbars 滚动条美化
pace-progress  浏览器加载
pjax 局部刷新
select2 下拉框美化插件
select2-bootstrap4-theme
tempusdominus-bootstrap-4 日期选择器插件
toastr 消息提示插件










