<?php
/**
 * +----------------------------------------------------------------------
 * | 推荐路线控制器
 * +----------------------------------------------------------------------
 *                      .::::.
 *                    .::::::::.            | AUTHOR: siyu
 *                    :::::::::::           | EMAIL: 407593529@qq.com
 *                 ..:::::::::::'           | DATETIME: 2023/05/04
 *             '::::::::::::'
 *                .::::::::::
 *           '::::::::::::::..
 *                ..::::::::::::.
 *              ``::::::::::::::::
 *               ::::``:::::::::'        .:::.
 *              ::::'   ':::::'       .::::::::.
 *            .::::'      ::::     .:::::::'::::.
 *           .:::'       :::::  .:::::::::' ':::::.
 *          .::'        :::::.:::::::::'      ':::::.
 *         .::'         ::::::::::::::'         ``::::.
 *     ...:::           ::::::::::::'              ``::.
 *   ```` ':.          ':::::::::'                  ::::..
 *                      '.:::::'                    ':'````..
 * +----------------------------------------------------------------------
 */
namespace app\admin\controller;

// 引入框架内置类
use think\facade\Db;
use think\facade\Request;

// 引入表格和表单构建器
use app\common\facade\MakeBuilder;
use app\common\builder\FormBuilder;
use app\common\builder\TableBuilder;

class PublishLine extends Base
{
//    // 验证器
//    protected $validate = 'PublishLine';
//
//    // 当前主表
//    protected $tableName = 'publishline';
//
//    // 当前主模型
//    protected $modelName = 'PublishLine';

    public function List(){

    }
    public function Save(){
        $data = ['start_place' => '广安', 'end_place' => '巴中','create_time'=>time()];
        Db::name('publishline')->insert($data);

    }

    public function Update(){

    }

    public function Delete(){

    }



}
