<?php
/**
 * +----------------------------------------------------------------------
 * | 行程管理控制器
 * +----------------------------------------------------------------------
 *                      .::::.
 *                    .::::::::.            | AUTHOR: siyu
 *                    :::::::::::           | EMAIL: 407593529@qq.com
 *                 ..:::::::::::'           | DATETIME: 2023/05/04
 *             '::::::::::::'
 *                .::::::::::
 *           '::::::::::::::..
 *                ..::::::::::::.
 *              ``::::::::::::::::
 *               ::::``:::::::::'        .:::.
 *              ::::'   ':::::'       .::::::::.
 *            .::::'      ::::     .:::::::'::::.
 *           .:::'       :::::  .:::::::::' ':::::.
 *          .::'        :::::.:::::::::'      ':::::.
 *         .::'         ::::::::::::::'         ``::::.
 *     ...:::           ::::::::::::'              ``::.
 *   ```` ':.          ':::::::::'                  ::::..
 *                      '.:::::'                    ':'````..
 * +----------------------------------------------------------------------
 */
namespace app\admin\controller;

// 引入框架内置类
use think\facade\Request;

// 引入表格和表单构建器
use app\common\facade\MakeBuilder;
use app\common\builder\FormBuilder;
use app\common\builder\TableBuilder;

class LineGroup extends Base
{
//    // 验证器
//    protected $validate = 'LineGroup';
//
//    // 当前主表
//    protected $tableName = 'line_group';
//
//    // 当前主模型
//    protected $modelName = 'LineGroup';
//

//行程列表
    public  function Index(){
        echo "first Controller,行程管理ddd";

    }
    //发布行程
    public  function Add(){

        echo "first Controller,行程管理ddd";

    }
    //保存行程
    public  function Save(){

        echo "first Controller,行程管理ddd";

    }
    //更新行程
    public  function Update(){
        echo "first Controller,行程管理ddd";

    }
    //删除行程
    public  function Del(){
        echo "first Controller,行程管理ddd";

    }



}
