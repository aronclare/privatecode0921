<?php

return array (
  'field_1' => 
  array (
    'title' => '文本框：',
    'type' => 'text',
    'options' => 
    array (
    ),
    'value' => '文本框的值',
  ),
  'field_2' => 
  array (
    'title' => '文本域：',
    'type' => 'textarea',
    'options' => 
    array (
    ),
    'value' => '文本域的值',
  ),
  'field_3' => 
  array (
    'title' => '单选：',
    'type' => 'radio',
    'options' => 
    array (
      1 => '是',
      0 => '否',
    ),
    'value' => '0',
  ),
  'field_4' => 
  array (
    'title' => '多选：',
    'type' => 'checkbox',
    'options' => 
    array (
      1 => '选项1',
      2 => '选项2',
      3 => '选项3',
    ),
    'value' => '1,2',
  ),
  'field_5' => 
  array (
    'title' => '下拉：',
    'type' => 'select',
    'options' => 
    array (
      1 => '选项1',
      2 => '选项2',
      3 => '选项3',
    ),
    'value' => '1',
  ),
);
