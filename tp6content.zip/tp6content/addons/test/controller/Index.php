<?php
namespace addons\test\controller;

class Index
{
    public function link()
    {
        echo 'hello link';
    }

    public function test()
    {
        echo 'hello test';
    }
}